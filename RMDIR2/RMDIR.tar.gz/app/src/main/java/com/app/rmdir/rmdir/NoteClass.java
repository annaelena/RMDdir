package com.app.rmdir.rmdir;

/**
 * Created by carlo on 11/04/2016.
 */
public class NoteClass {
    String titolo;
    String nota;
    int id;

    NoteClass(String titolo, String nota, int id) {
        this.titolo = titolo;
        this.nota = nota;
        this.id=id;
    }
}