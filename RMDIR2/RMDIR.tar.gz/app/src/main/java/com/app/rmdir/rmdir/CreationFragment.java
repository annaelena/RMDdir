package com.app.rmdir.rmdir;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link creationFragmentInterface} interface
 * to handle interaction events.
 */
public class CreationFragment extends Fragment {

    private creationFragmentInterface mListener;
    private boolean recording =false;
    public CreationFragment() {}
    String mNickname, mTesto, mTitolo, mId=null;

    public static CreationFragment getIstance(String nickname) {
        CreationFragment creationFragment =new CreationFragment();
        Bundle bundle = new Bundle();
        bundle.putString("nickname",nickname);
        creationFragment.setArguments(bundle);
        return creationFragment;
    }
    public static CreationFragment getIstance(String nickname,String aTesto, String aId, String aTitolo) {
        CreationFragment creationFragment =new CreationFragment();
        Bundle bundle = new Bundle();
        bundle.putString("nickname",nickname);
        bundle.putString("testo",aTesto);
        bundle.putString("id",aId);
        bundle.putString("titolo",aTitolo);
        creationFragment.setArguments(bundle);
        return creationFragment;
    }

    private AHBottomNavigation bottomNavigation;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_creation, container, false);
        final EditText titolo = (EditText)view.findViewById(R.id.input_titolo);
        final EditText testo =(EditText)view.findViewById(R.id.testo);


        bottomNavigation = (AHBottomNavigation) view.findViewById(R.id.bottom_navigation);
        //AHBottomNavigationItem item1 = new AHBottomNavigationItem(R.string.tab_1, R.drawable.ic_maps_place, R.color.color_tab_1);

        AHBottomNavigationItem media = new AHBottomNavigationItem("Media", R.drawable.media);
        AHBottomNavigationItem insert = new AHBottomNavigationItem("Inserisci", R.drawable.insert);
        AHBottomNavigationItem rec = new AHBottomNavigationItem("Rec", R.drawable.rec);
        bottomNavigation.setDefaultBackgroundColor(Color.parseColor("#FEFEFE"));
        bottomNavigation.setBehaviorTranslationEnabled(false);
        bottomNavigation.addItem(media);
        bottomNavigation.addItem(insert);
        bottomNavigation.addItem(rec);
        if(getArguments().getString("id")!=null)
        {
            mId=getArguments().getString("id");
            mTesto=getArguments().getString("testo");
            mTitolo=getArguments().getString("titolo");
            mNickname=getArguments().getString("nickname");
        }
        titolo.setText(mTitolo);
        testo.setText(mTesto);




        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public void onTabSelected(int position, boolean wasSelected) {
                if (position == 0) {
                    /*fragmentManager.beginTransaction()
                            .replace(R.id.frame, storeList, ELENCO)
                            .commit();*/
                }
                if (position == 1) {
                    if(mId==null){
                        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                        asyncHttpClient.addHeader("Content-Type", "application/x-www-form-urlencoded");
                        RequestParams requestParams = new RequestParams();
                        requestParams.add("nickname",mNickname );
                        requestParams.add("Testo_nota",testo.getText().toString());
                        requestParams.add("Title",titolo.getText().toString());
                        asyncHttpClient.post("http://rmdir.altervista.org/InsertNote.php", requestParams, new AsyncHttpResponseHandler() {
                            @Override
                            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                                try {
                                    JSONObject jsonObject = new JSONObject(new String(responseBody));
                                    Log.d("Prova", jsonObject.toString());
                                    if ((jsonObject.getBoolean("success"))) {
                                        Log.d("caricamento nota", "ok");
                                        mListener.onCreationInteraction();
                                    } else {
                                        Toast.makeText(getActivity(), jsonObject.getString("data"), Toast.LENGTH_LONG).show();
                                    }
                                } catch (JSONException e) {
                                    Toast.makeText(getActivity(), "Error on jsonObject", Toast.LENGTH_LONG).show();
                                }
                            }

                            @Override
                            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                                Toast.makeText(getActivity(), "Error on connection", Toast.LENGTH_LONG).show();

                            }
                        });





                    }
                    else
                    {
                        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
                        asyncHttpClient.addHeader("Content-Type", "application/x-www-form-urlencoded");
                        RequestParams requestParams = new RequestParams();
                        requestParams.add("id",mId );
                        requestParams.add("nickname",mNickname );
                        requestParams.add("Testo_nota",testo.getText().toString());
                        requestParams.add("Title",titolo.getText().toString());
                        asyncHttpClient.post("http://rmdir.altervista.org/updateNote.php", requestParams, new AsyncHttpResponseHandler() {
                            @Override
                            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                                try {
                                    JSONObject jsonObject = new JSONObject(new String(responseBody));
                                    Log.d("Prova", jsonObject.toString());
                                    if ((jsonObject.getBoolean("success"))) {
                                        Log.d("caricamento nota", "ok");
                                        mListener.onCreationInteraction();
                                    } else {
                                        Toast.makeText(getActivity(), jsonObject.getString("data"), Toast.LENGTH_LONG).show();
                                    }
                                } catch (JSONException e) {
                                    Toast.makeText(getActivity(), "Error on jsonObject", Toast.LENGTH_LONG).show();
                                }
                            }

                            @Override
                            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                                Toast.makeText(getActivity(), "Error on connection", Toast.LENGTH_LONG).show();

                            }
                        });

                    }



        }
                if (position == 2) {

                }
            }
        });
        bottomNavigation.setCurrentItem(-1);


        return  view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof creationFragmentInterface) {
            mListener = (creationFragmentInterface) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface creationFragmentInterface {
        // TODO: Update argument type and name
        void onCreationInteraction();
    }
}
