package com.app.rmdir.rmdir;


import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

import cz.msebera.android.httpclient.Header;


/**
 * A simple {@link Fragment} subclass.
 */
public class DetailFragment extends Fragment {

    private static final String NOTE = "note";

    private static final String NICKNAME = "nickname";

    public interface IODetailFragment{
        void onChoice( String aChoice,String aId);
    }

    ImageButton btn1;
    static TextView textView1;
    static TextView textView2;

    static String notaSelected, nickname;

    public static DetailFragment getInstance(String note, String nickname){

        DetailFragment detailFragment = new DetailFragment();
        Bundle  bundle = new Bundle();
        bundle.putString(NOTE,note);
        bundle.putString(NICKNAME,nickname);
        detailFragment.setArguments(bundle);
        return detailFragment;




    }

    public IODetailFragment mListener = new IODetailFragment() {
        @Override
        public void onChoice(String aChoice,String aId) {

        }
    };


    public DetailFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_detail, container, false);
        Bundle bundle = getArguments();
        notaSelected = bundle.getString(NOTE).toString();
        nickname= bundle.getString(NICKNAME).toString();
        AHBottomNavigation bottomNavigation;
        bottomNavigation = (AHBottomNavigation) view.findViewById(R.id.bottom_navigation);
        //AHBottomNavigationItem item1 = new AHBottomNavigationItem(R.string.tab_1, R.drawable.ic_maps_place, R.color.color_tab_1);

        AHBottomNavigationItem media = new AHBottomNavigationItem("modify", R.drawable.insert);
        AHBottomNavigationItem insert = new AHBottomNavigationItem("media", R.drawable.media);
        AHBottomNavigationItem rec = new AHBottomNavigationItem("delete", R.drawable.rec);
        bottomNavigation.setDefaultBackgroundColor(Color.parseColor("#FEFEFE"));
        bottomNavigation.setBehaviorTranslationEnabled(false);
        bottomNavigation.addItem(media);
        bottomNavigation.addItem(insert);
        bottomNavigation.addItem(rec);
        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public void onTabSelected(int position, boolean wasSelected) {
                if (position == 0) {
                    mListener.onChoice("modify",notaSelected);
                }
                if (position == 1) {

                    mListener.onChoice("media",notaSelected);
                }
                if (position == 2) {
                    mListener.onChoice("delete",notaSelected);

                }
            }
        });


        textView1 = (TextView)view.findViewById(R.id.textView1);
        textView2 = (TextView)view.findViewById(R.id.textView2);

       btn1 = (ImageButton)view.findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onChoice("share",notaSelected);

            }
        });

        try {
            DataForm(view);
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return view;
    }
    public void DataForm( View view) throws JSONException, UnsupportedEncodingException, NoSuchAlgorithmException {
        //start here
        RequestParams params = new RequestParams();
        params.put("nickname", nickname);
        params.put("Id_nota",notaSelected);
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        asyncHttpClient.addHeader("Content-Type", "application/x-www-form-urlencoded");
        asyncHttpClient.post("http://rmdir.altervista.org/NoteDetail.php", params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                // If the response is JSONObject instead of expected JSONObject
                JSONObject note;
                try {
                    JSONObject jsonObject = new JSONObject(new String(responseBody));
                    note = new JSONObject(jsonObject.get("data").toString());
                    dataGetted(note);

                    // DownloadData(session);
                } catch (Exception e) {
                    Log.d("errorr", e.getMessage());
                }
                Log.d("jsoon", "letto get");

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.d("errorr", responseBody.toString() + statusCode);

            }
        });
        //end
    }
    public static void dataGetted(JSONObject note) throws JSONException {

                Log.d("debbuging",note.getString("Id_nota").toString()+nickname+note);

        textView1.setText("" + note.getString("Titolo"));
        textView2.setText("" + note.getString("Testo_nota"));


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(getActivity()instanceof IODetailFragment){
            mListener = (IODetailFragment)getActivity();

        }
    }
}
